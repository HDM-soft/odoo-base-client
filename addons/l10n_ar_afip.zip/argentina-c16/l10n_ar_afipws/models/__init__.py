##############################################################################
# For copyright and license notices, see __manifest__.py file in module root
# directory
##############################################################################
from . import afipws_certificate_alias
from . import afipws_certificate
from . import afipws_connection
from . import res_company
from . import res_config_settings
from . import res_partner
