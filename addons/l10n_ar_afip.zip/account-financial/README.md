[![Code Climate](https://codeclimate.com/github/ingadhoc/account-financial-tools/badges/gpa.svg)](https://codeclimate.com/github/ingadhoc/account-financial-tools)

# ADHOC Odoo Accountant Financial Tools and Utils

Modules that extend odoo for common needs of ADHOC Customers

[//]: # (addons)
[//]: # (end addons)

Translation Status
------------------
[![Transifex Status](https://www.transifex.com/projects/p/ingadhoc-account-financial-tools-15-0/chart/image_png)](https://www.transifex.com/projects/p/ingadhoc-account-financial-tools-15-0)
----

<img alt="ADHOC" src="http://fotos.subefotos.com/83fed853c1e15a8023b86b2b22d6145bo.png" />
**Adhoc SA** - www.adhoc.com.ar
