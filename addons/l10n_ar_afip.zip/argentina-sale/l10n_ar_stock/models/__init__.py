##############################################################################
# For copyright and license notices, see __manifest__.py file in module root
# directory
##############################################################################
from . import res_company
from . import stock_book
from . import stock_picking
from . import product_template
from . import uom_uom
from . import stock_lot
from . import account_chart_template
