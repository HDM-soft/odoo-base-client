##############################################################################
# For copyright and license notices, see __manifest__.py file in module root
# directory
##############################################################################
from . import sale_checkbook
from . import sale_order
from . import sale_order_line
from . import account_chart_template
