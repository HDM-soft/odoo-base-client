[![Code Climate](https://codeclimate.com/github/ingadhoc/argentina-sale/badges/gpa.svg)](https://codeclimate.com/github/ingadhoc/argentina-sale)

# ADHOC Odoo Argentina Sale

Modules that extend odoo for common needs of ADHOC Customers

[//]: # (addons)
[//]: # (end addons)

Translation Status
------------------
[![Transifex Status](https://www.transifex.com/projects/p/ingadhoc-argentina-sale-15-0/chart/image_png)](https://www.transifex.com/projects/p/ingadhoc-argentina-sale-15-0)
----

<img alt="ADHOC" src="http://fotos.subefotos.com/83fed853c1e15a8023b86b2b22d6145bo.png" />
**Adhoc SA** - www.adhoc.com.ar
